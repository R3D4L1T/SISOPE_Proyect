﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoColegio.Domain
{
    public class Rol
    {
        [Key]
        public int RoleID { get; set; }
        [MaxLength(30)] //Admin, Instructor, Estudiante
        public string Description { get; set; }
        // public ICollection<Usuario>? Usuarios { get; set; }


        // Cambios realizados para hacer la colección de solo lectura
        private readonly List<Usuario> _usuarios = new List<Usuario>();
        public IReadOnlyCollection<Usuario> Usuarios => _usuarios.AsReadOnly();

        // Método para agregar elementos a la colección
        public void AgregarUsuario(Usuario usuario)
        {
            if (usuario == null) throw new ArgumentNullException(nameof(usuario));
            _usuarios.Add(usuario);
        }

        // Método para remover elementos de la colección (opcional)
        public bool RemoverUsuario(Usuario usuario)
        {
            if (usuario == null) throw new ArgumentNullException(nameof(usuario));
            return _usuarios.Remove(usuario);
        }
    }
}
