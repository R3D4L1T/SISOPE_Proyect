﻿namespace ProyectoColegio.Repositories.Implementations
{
    public class RepositoryBase
    {

    }
}