﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoColegio.Domain
{
    public class DetalleCursoViewModel
    {
        public string NombreCurso { get; set; }
        public float C1 { get; set; }
        public float C2 { get; set; }
        public float C3 { get; set; }
        public float C4 { get; set; }
        public float Final { get; set; }
    }
}
